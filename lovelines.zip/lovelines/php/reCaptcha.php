<script src="https://www.google.com/recaptcha/api.js"></script>
<script>
    function onSubmit(token) {
        document.getElementById("demo-form").submit();
    }
</script>

<?php
$sitekey="6LcVinkaAAAAAFCD3eYUukNyoHT0eFumM8r9IwNv";
?>


